const queryAllProducts = `
    query {
        listProducts {
        items {
            id
            name
            reviews {
            items {
                id
                rating
                content
            }
            }
        }
        }
    }
`;

export { queryAllProducts };
